module wochenplaner {
}